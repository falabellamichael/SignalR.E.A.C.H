/*
 * Emerald Horizon shader adapted for the dependency-free REACH welcome page.
 * https://tools.animatedwebs.com/three-js/structure-flow/emerald-horizon
 * Original: assets/EmeraldHorizonBackground-BO9EBzhO.js (retrieved 2026-11-01).
 * The fullscreen WebGL host below replaces the React/Three.js wrapper.
 *
 * MIT License
 * Copyright (c) 2026 Meng To
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
(() => {
  const canvas = document.querySelector('.welcome-horizon');
  if (!canvas) return;
  const gl = canvas.getContext('webgl', {
    alpha: false, antialias: false, depth: false, stencil: false,
    powerPreference: 'low-power'
  });
  if (!gl) { canvas.hidden = true; return; }

  const vertexSource = `
    attribute vec2 position;
    void main() { gl_Position = vec4(position, 0.0, 1.0); }
  `;
  const fragmentSource = `
    precision mediump float;
    uniform float u_time;
    uniform vec2 u_resolution;
    float hash(float n) { return fract(sin(n) * 1e4); }
    float noise(float x) {
      float i = floor(x);
      float f = fract(x);
      float u = f * f * (3.0 - 2.0 * f);
      return mix(hash(i), hash(i + 1.0), u);
    }
    void main() {
      vec2 st = gl_FragCoord.xy / u_resolution.xy;
      float wave1 = sin(st.x * 3.0 + u_time * 0.5) * 0.1;
      float wave2 = sin(st.x * 5.0 - u_time * 0.3) * 0.05;
      // Equivalent descending ramps with defined GLSL smoothstep edge order.
      float intensity = 1.0 - smoothstep(-0.1, 0.4, st.y + wave1 + wave2);
      float variation = noise(st.x * 2.0 + u_time * 0.1) * 0.5 + 0.5;
      intensity *= variation * 1.5;
      vec3 glowColor1 = vec3(0.05, 0.8, 0.2);
      vec3 glowColor2 = vec3(0.0, 1.0, 0.5);
      vec3 finalGlow = mix(glowColor1, glowColor2, st.x + sin(u_time * 0.2) * 0.5);
      vec3 color = vec3(0.0, 0.02, 0.0) + finalGlow * pow(intensity, 1.5) * 1.2;
      float vignette = 1.0 - smoothstep(0.5, 1.2, length(st - vec2(0.5, 0.0)));
      gl_FragColor = vec4(color * vignette, 1.0);
    }
  `;

  const shaders = [];
  const program = gl.createProgram();
  const buffer = gl.createBuffer();
  try {
    if (!program || !buffer) throw new Error('WebGL resources unavailable');
    for (const [type, source] of [[gl.VERTEX_SHADER, vertexSource], [gl.FRAGMENT_SHADER, fragmentSource]]) {
      const shader = gl.createShader(type);
      if (!shader) throw new Error('Shader unavailable');
      shaders.push(shader);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error('Shader compilation failed');
      gl.attachShader(program, shader);
    }
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error('Shader linking failed');
  } catch (_) {
    if (program) gl.deleteProgram(program);
    if (buffer) gl.deleteBuffer(buffer);
    canvas.hidden = true;
    return; // The CSS horizon remains available without WebGL.
  } finally {
    shaders.forEach(shader => gl.deleteShader(shader));
  }

  gl.useProgram(program);
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const position = gl.getAttribLocation(program, 'position');
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
  const timeUniform = gl.getUniformLocation(program, 'u_time');
  const resolutionUniform = gl.getUniformLocation(program, 'u_resolution');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const root = document.documentElement;
  let frame = 0, elapsed = 0, previous = null, lastDraw = -Infinity;
  let resize = true, lost = false;

  function moving() { return !reduced.matches && root.dataset.motion !== 'off'; }
  function draw(time) {
    frame = 0;
    if (document.hidden || lost) return;
    const animate = moving();
    if (animate && previous !== null) elapsed += Math.min(time - previous, 100) / 1000;
    previous = animate ? time : null;
    if (resize) {
      const {width, height} = canvas.getBoundingClientRect();
      // Cap fill rate on large/high-density displays and phones.
      const ratio = Math.min(window.devicePixelRatio || 1, 1.5, 1600 / Math.max(width, height, 1));
      canvas.width = Math.max(1, Math.round(width * ratio));
      canvas.height = Math.max(1, Math.round(height * ratio));
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.uniform2f(resolutionUniform, canvas.width, canvas.height);
      resize = false;
      lastDraw = -Infinity;
    }
    if (!animate || time - lastDraw >= 32) {
      gl.uniform1f(timeUniform, elapsed);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      lastDraw = time;
    }
    if (animate) frame = requestAnimationFrame(draw);
  }
  function refresh() {
    cancelAnimationFrame(frame);
    previous = null;
    lastDraw = -Infinity;
    frame = document.hidden || lost ? 0 : requestAnimationFrame(draw);
  }
  new ResizeObserver(() => { resize = true; refresh(); }).observe(canvas.parentElement);
  new MutationObserver(refresh).observe(root, {attributes: true, attributeFilter: ['data-motion']});
  reduced.addEventListener('change', refresh);
  document.addEventListener('visibilitychange', refresh);
  canvas.addEventListener('webglcontextlost', () => {
    lost = true;
    canvas.hidden = true;
    refresh();
  });
  refresh();
})();
